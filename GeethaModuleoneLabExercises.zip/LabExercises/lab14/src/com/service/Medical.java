package com.service;

public interface Medical {
	public void storeInService();
	
}
