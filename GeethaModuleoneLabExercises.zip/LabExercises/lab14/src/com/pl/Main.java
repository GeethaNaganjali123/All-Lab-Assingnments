package com.pl;
import java.util.*;
public class Main {
	public static void main(String args[])
	{ 
		int g;
		CustomerDetails ad=new CustomerDetails();
		Scanner s=new Scanner(System.in);
		
		
		do
		{
			 System.out.println("Specify your choice:");
			 g =s.nextInt();
			switch(g)
			{
			case 1:
				ad.Add();
				break;
			case 2:
				ad.Retrieve();
				break;
			case 3:
				System.out.println(" Exit:");
				break;
			}
			
		}
		while(g!=3);
		s.close();
	}
}


