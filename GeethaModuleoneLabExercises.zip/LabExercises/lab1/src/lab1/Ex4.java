package lab1;
import java.util.Scanner;
public class Ex4 {
	public static void main(String args[])
    {
		int i;
		boolean flag=false;
		Scanner s=new Scanner(System.in);
		i=s.nextInt();
		int Digit=i%10;
		{
		i=i/10;
		while(i>10)
		{
			if(Digit<=i%10) 
				flag=true;
				break;
				
			}
			Digit=i%10;
			i=i/10;
			if(flag) {
				System.out.println("not an increasing number");
			}
			else {
				System.out.println("is an increasing number");
			}
		}
    }
	
}
