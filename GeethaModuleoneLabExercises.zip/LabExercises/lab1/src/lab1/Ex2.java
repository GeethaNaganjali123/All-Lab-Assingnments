package lab1;
import java.util.Scanner;


class square
{
	int n;
	int caldiff(int n)
	{
		int i,j,k,l;
		i=n*(n+1)*(2*n+1)/6;
		j=n*(n+1)/2;
		k=j*j;
        l=i-k;
        System.out.println("diff:" +l);
        return n;
	}
	
	
}
public class Ex2 {
	public static void main(String args[])
	{
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		square ob=new square();
		ob.caldiff(n);
	}
}
