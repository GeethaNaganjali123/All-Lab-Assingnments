package lab1;
import java.util.Scanner;
public class Ex3 {
	 public static void main(String args[])
	   {
	    	Scanner sc=new Scanner(System.in);
	    	int n=sc.nextInt();
	    	if (checknumber (n))
	    	
	    		System.out.println(n+ " is power of 2");
	        
	       else
	    		System.out.println(n+" is not power of 2");
	    }
	    	
	    static boolean checknumber(int n) 
	    {
	    	while(n>1)	
	    	{
	    		if(n%2!=0)
	    		{
	    			return false;
	    		}
	    		n=n/2;
	    	}
	    	return true;
	    	
	    }
}
