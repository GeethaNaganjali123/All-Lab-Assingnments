package lab4;
import java.util.Scanner;
import java.io.*;
public class Sumofcubesofndigitnum {
     public static void main(String args[])
     {
    	 Scanner sc=new Scanner(System.in);
    	 int n=sc.nextInt();
    	
    	 cubeofnum g=new cubeofnum();
    	 int res=g.arm(n);
    	
    	 System.out.println("The sum is:"+res);
     }
}
class cubeofnum{
	int s=0;
	 
	 int arm(int b)
	 {
		 
		 while(b!=0)
		 {
			 int t=b%10;
			 s=s+t*t*t;
			 b=b/10;
		 }
		return s; 
	 }
	 
}
