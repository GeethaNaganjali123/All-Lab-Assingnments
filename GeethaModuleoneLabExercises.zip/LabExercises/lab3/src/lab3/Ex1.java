package lab3;
import java.util.Arrays;


public class Ex1 {
	int[]getsorted(int a[])
    {
    	int length=a.length;
    	int b[]=new int[length];
    	int k=0;
    	int t;
    	
    	for(int g=a.length-1;g>=0;g--)
    	{
    		b[k]=a[g];
    		k++;
    	}
    	for(int p=0;p<length;p++)
    	{
    		for(int q=p+1;q<length;q++)
    		{
    			if(b[p]>b[q])
    			{
    				t=b[p];
    				b[p]=b[q];
    				b[q]=t;
    			}
    		}
    	}
    	return b;
    }
    public static void main(String args[])
    		{
    	       int a[]=new int[6];
    	       int g[]=new int[6];
    	       a[0]=8;
    	       a[1]=10;
    	       a[2]=6;
    	       a[3]=2;
    	       a[4]=9;
    	       a[5]=4;
    	       Ex1 s=new Ex1();
    	       g=s.getsorted(a);
    	       System.out.println(Arrays.toString(g));
    		}
    
}

