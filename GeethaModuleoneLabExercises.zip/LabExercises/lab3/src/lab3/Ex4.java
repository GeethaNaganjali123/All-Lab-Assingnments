package lab3;
import java.util.Scanner;
public class Ex4 {
	 public static void main(String args[])
     {
    	 Scanner O=new Scanner(System.in);
    	 char ch[]=new char[20];
    	 System.out.println("enter the string:");
    	 ch=O.next().toCharArray();
    	 int len=ch.length;
    	 int count=0,flag=0;
    	 for (int i=0;i<len;i++)
    	 {
    		 count=0;
    		 for(int j=0;j<len;j++)
    		 {
    			 if(ch[j]==ch[i])
    			    count++;
    			 for(int k=0;k<i;k++)
    			 {
    				 if(ch[k]==ch[i])
    					 flag=1;
    			 }
    		 }
    	 
    	 if(flag==0)

         System.out.println(ch[i]+":"+count);
    	 }	 
    }
}






