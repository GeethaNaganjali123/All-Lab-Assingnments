package lab3;



public class Ex3 {
	int a[]= {11,44,67,89,30};
    int length=5;
    int getSecondSmallest() 
    {
    	int temp = 0;
    	for(int i=0;i<length;i++)
    	{
    		for(int j=i+1;j<length;j++) 
    		{
    			if(a[i]>a[j])
    			{
    				temp=a[i];
    				a[i]=a[j];
    				a[j]=temp;
    			}
    		}
    	}
    	return a[1];
    }
 public static void main(String args[])
 {
	 Ex3 obj=new Ex3();
	 System.out.println(obj.getSecondSmallest());
 }
}
