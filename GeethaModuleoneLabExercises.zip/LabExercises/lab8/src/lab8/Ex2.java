package lab8;
import java.io.IOException;
import java.io.RandomAccessFile;


public class Ex2 
{
     int linecount=0;
     public void readRAF() throws IOException
     {
    	 try 
    	 {
    		 RandomAccessFile rafObj=new RandomAccessFile("C:\\geetha\\numbering.txt","r");
    		 String a;
    		 while((a=rafObj.readLine())!=null)
    		 {
    			 for(int i=0;i<a.length();)
    			 {
    				 linecount++;
    				 System.out.println(linecount+a);
    				 break;
    			 }
    		 }
    	 
    	 
    	 rafObj.close();
    	 }
     catch(Exception e)
     
     {
    	 System.out.println(e);
     }
   }

public static void main(String args[]) throws IOException
     {
	Ex2 rafObj=new Ex2();
	rafObj.readRAF();
     }
}