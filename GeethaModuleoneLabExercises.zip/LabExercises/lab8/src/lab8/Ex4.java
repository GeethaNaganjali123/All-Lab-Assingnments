package lab8;
import java.io.File;
import java.util.*;
public class Ex4 {
    public static void main(String [] args) {
    	Scanner keyboard=new Scanner(System.in);
    	String g=keyboard.nextLine();
    	File f=new File(g);
    	    System.out.println("File Name:"+f.getName());
    	    System.out.println("File Is Readable or not:"+f.canRead());
    	    System.out.println("File is writeable or not:"+f.canWrite());
    	    System.out.println("File exists ot not:"+f.exists());
    	    System.out.println("File length in bytes:"+f.length());
    	    
    }
}
