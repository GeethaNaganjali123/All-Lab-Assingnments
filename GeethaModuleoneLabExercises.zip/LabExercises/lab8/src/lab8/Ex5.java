package lab8;
import java.util.Scanner;
public class Ex5 {
	public void Countingchar(String str)
	{
		int i=0,j=0;
		char ch[]=str.toCharArray();
		int l=ch.length;
		for(i=0;i<l-1;i++)
		{
			char chr =ch[i];
			char a=ch[i+1];
			if(chr>=a)
			{
				j=1;
				break;
			}
		}
		if (j==0)
		{
			System.out.println("Positive String!!");
			
		}
		else
		{
			System.out.println(" Not a Positive String!!");
		}
		
	
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string");
		String s=sc.nextLine().toUpperCase();
		Ex5 obj=new Ex5();
		obj.Countingchar(s);
	}
}
