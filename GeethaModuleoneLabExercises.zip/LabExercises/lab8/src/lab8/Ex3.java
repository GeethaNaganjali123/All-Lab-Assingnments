package lab8;
import java.io.*;
import java.io.IOException;
import java.io.RandomAccessFile;
public class Ex3 {
    int word=0;
    int chars=0;
    int line=0;
    public void readFile() throws IOException{
    	try {
    		RandomAccessFile raf=new RandomAccessFile("C:\\geetha\\numbering.txt","r");
    		String s;
    		while((s=raf.readLine())!=null) {
    			chars =chars+s.length();
    			String[] wordlist=s.split("\\s+");
    			word+=wordlist.length;
    			
    			String[] sentencelist=s.split("[!?.:]+");
    			line =line+sentencelist.length;
    		}
    		System.out.println("word count:"+word);
    		System.out.println("line count:"+line);
    		System.out.println("chars count:"+chars);
    		raf.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
    }
    public static void main(String args[]) throws IOException
    {
    	Ex3 c=new Ex3();
    	c.readFile();
    }
}
