package lab8;
import java.util.*;
public class Ex1 {
    public static void main(String args[])
    {
    	int n,sum=0;
    	Scanner s=new Scanner(System.in);
    	String str=s.nextLine();
    	StringTokenizer str1= new StringTokenizer(str);
    	while(str1.hasMoreTokens()) {
    		n=Integer.parseInt(str1.nextToken());
    		System.out.println(n);
    		sum=sum+n;
    	}
    	System.out.println("sum: "+sum);
    	s.close();
    }
}
