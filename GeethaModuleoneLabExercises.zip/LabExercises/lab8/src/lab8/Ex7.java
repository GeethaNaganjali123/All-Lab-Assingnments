package lab8;

public class Ex7 
{
	public static boolean validate(String g) 
	{
        String s = g.substring(0,g.length()-4);
        if(g.substring(8,g.length()).equals("_job") && s.length()==8) 
        {
            return true;
        }
        else
            return false;
    }
public static void main(String args[])
{
    System.out.println(validate("geethana_job"));
}

 

}


