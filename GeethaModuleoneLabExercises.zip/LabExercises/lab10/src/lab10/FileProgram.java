package lab10;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class FileProgram {
  public static void main(String[] args) throws IOException {
	  try {
		  FileInputStream fisObj= new FileInputStream("C:\\geetha\\source.txt");
		  FileOutputStream fosObj=new FileOutputStream("C:\\\\geetha\\\\target.txt");
		  CopyDataThread cdt=new CopyDataThread(fisObj,fosObj);
		  cdt.start();
	  }catch(Exception e) {
		  System.out.println(e);
	  }
  }
}
