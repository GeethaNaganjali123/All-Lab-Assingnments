package lab10;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class CopyDataThread  extends Thread{
	FileInputStream fisObj;
	FileOutputStream fosObj;
	
	public CopyDataThread(FileInputStream fisObj,FileOutputStream fosObj) {
		this.fisObj=fisObj;
		this.fosObj = fosObj;
	}
	public void run() {
		try {
			int a,i=0;
			while((a=fisObj.read()) !=-1){
				fosObj.write(a);
				i++;
				if(i%10==0) {
				
					System.out.println("10 characters are copied.");
				try {
					sleep(10000);
				
				}
				catch(InterruptedException e) {
					System.out.println("This should not come.");
				}
			}
		}
		fisObj.close();
		fosObj.close();
		System.out.println("Copy Successful.");
	}catch(IOException e) {
		System.out.println(e);
	}
 }
}
