package lab11;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
class MusicPlayerTask implements Runnable{
	
	
	public void run() {
		System.out.println("Music play is executing.");
		try {
			Thread.sleep(2000);
		}catch(InterruptedException e) {
			System.out.println("Music play Exception");
		}
		System.out.println("Music play is resumed after sleep.");
	}
	
}
class CopyTask implements Runnable{
	
	public void run()
	{
		System.out.println("CopyTask is Executing");
	    try
	    {
	    	Thread.sleep(2000);
	    }
	
	catch(InterruptedException e) {
		System.out.println("Copy Task Exception");
	}
	System.out.println("Copy Task is resumed after sleep");
}
}
public class Ex1 {
      public static void main(String args[]) {
    	  Scanner s=new Scanner(System.in);
    	  System.out.println("Thread Executor & Executor Service Demo \n 1.Execution Service\n Enter your choice:");
    	  int ch = s.nextInt();
    	  if(ch==1) 
    	  {
    		 ExecutorService e1=Executors.newSingleThreadExecutor();
    		 ExecutorService e2=Executors.newFixedThreadPool(8);
    		 e1.execute(new MusicPlayerTask());
    		 e2.execute(new CopyTask());
    		 e1.shutdown();
    		 e2.shutdown();
    		 
     }
    	  else 
    	  {
    		  System.out.println("Enter valid choice");
    	  }
    	  s.close();
      }
}
