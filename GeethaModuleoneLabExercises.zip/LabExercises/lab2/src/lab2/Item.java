package lab2;

public abstract class Item {


public String tostring() 
{
	return "Item[Identificationno=" + Identificationno + ", title=" + "No_of_copies" +"]";
}
private int Identificationno;
private int title;
private int No_of_copies;
public Item()
 { 
	
}
	private int getIdentificationno()
	{
		return Identificationno;
	}
	private void setIdentificationno(int identificationno) 
	{
		Identificationno=identificationno;
}
	private int getTitle() {
		return title;
	}
	private void settitle(int title) {
		this.title=title;
	}
	private int getNo_of_copies()
	{
		return No_of_copies;
	}
	private void setNo_of_copies(int  no_of_copies) 
	{
		 No_of_copies= no_of_copies;
	}
	abstract class WrittenItem extends Item
	{
		private String author;
		private String getAuthor()
		{
			return author;
		}
		private void setauthor(String author) {
			this.author=author;
		}
		public String tostring() {
			return "WrittenItem[authors="+ author+"]";
		}
		class Book extends WrittenItem{
			
		}
		class JournalPaper extends WrittenItem{
			private int yearPublished;
		}
		abstract class mediaItem extends Item
		{
			private int runtime;
			private int grtRuntime()
			{
				return runtime;
			}
			private void SetRuntime(int runtime)
			{
				this.runtime=runtime;
			}
			
			
			public String toString()
			{
				return "mediaItem[return="+runtime+"]";
			}
			private mediaItem() {
				super();
			}
			class video extends mediaItem
			{
				private String director;
				private String game;
				private int yearreleased;
			}
			class CD extends mediaItem
			{
				private String artist;
				private String game;
			}
		}
		
	}
}
