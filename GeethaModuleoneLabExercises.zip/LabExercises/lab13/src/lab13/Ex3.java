package lab13;
import java.util.Scanner;

public class Ex3 {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		String g=sc.next();
		System.out.println("Enter name "+ g);
		String p=sc.next();
		System.out.println("Enter password" + p);
		labm j=(i,b)->{if (i.equals(g)&& b.equals(p))
			return true;
		else
			return false;
    };

      boolean c=j.print("geetha","123");
	
	        System.out.println(c);

      }
}




interface labm{
	public boolean  print(String a, String b);
}

