package lab13;
import java.util.*;


interface Factorial1{
	int fact(int g);
	
}

public class EX5 {
	public static void main(String args[]) {
		Scanner keyboard = new Scanner(System.in);
		int number = keyboard.nextInt();
		Factorial f=new Factorial();
		Factorial1 fact = f::factorial;
		int res = fact.fact(number);
		System.out.println(res);
	}
}
class Factorial
{
	 int factorial(int g) {
		int fa=1;
		for(int i=1;i<=g;i++)
		{
			fa=fa*i;
		}
		return fa;
	}

}
