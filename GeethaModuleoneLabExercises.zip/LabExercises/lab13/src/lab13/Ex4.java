package lab13;
import java.util.*;
import lab13.Employee.EmployeeDetails;

class Employee
{
	String name;
	int empid;
	public String getName() {
		return name;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public Employee(String name,int empid) {
		this.name = name;
		this.empid=empid;
	}
	
	interface EmployeeDetails{
		public Employee getEmployee(String name,Integer empid);
	}
	
}

public class Ex4 {
         public static void main(String[] args) {
        	 EmployeeDetails emp = Employee :: new;
        	 Employee em = emp.getEmployee("Geetha" ,30);
        	 System.out.println("Employee Name: "+em.getName());
        	 System.out.println("Employee ID: "+em.getEmpid());
         }
}
