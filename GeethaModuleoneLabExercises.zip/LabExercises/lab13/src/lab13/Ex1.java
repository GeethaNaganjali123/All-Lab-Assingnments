package lab13;
import java.util.*;
public class Ex1 {
           public static void main(String [] args)
           {
        	   Scanner k = new Scanner(System.in);
        	   int a=k.nextInt();
        	   int b=k.nextInt();
        	   Sum s=(c,d)-> Math.pow(c,d);
        	   double x=s.calSum(a,b);
        	   System.out.println(x);
           }
}
interface Sum
{
	double calSum(double x,double y);
}
