package lab13;
import java.util.*;
interface Space
{
	String space(String s);
}
public class Ex2 {
      public static void main(String args[]) {
    	  Scanner sc=new Scanner (System.in);
    	  String g=sc.nextLine();
    	  Space s1=(k)->giveSpace(k);
    	  System.out.println(s1.space(g));
      }
      static String giveSpace(String s2) {
    	  String k=" ";
    	  for(int i=0;i<s2.length();i++) {
    		  k=k+s2.charAt(i)+" ";
    	  }
    	  return k;
      }
}
