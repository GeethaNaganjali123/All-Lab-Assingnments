package lab5;

import java.util.Scanner;

public class Exc4 {
	public static void main(String args[])throws Exception
	   {
		   Scanner s=new Scanner(System.in);
		   
		   String firstName=null;
		   String lastName=null;
		   s.close();
		   try
		   {
			   if(firstName==null || lastName==null)
			   
				  System.out.println("Firstname and Lastname should not be blank!!");
				 else 
				System.out.println("Firstname: "+firstName+" Lastname: "+lastName);   
		    }
			   catch(Exception e)
			   {
				   
			     //System.out.println("Firstname: "+firstName+" Lastname: "+lastName);   
				   System.out.println(e);
			   }
		   }
}
