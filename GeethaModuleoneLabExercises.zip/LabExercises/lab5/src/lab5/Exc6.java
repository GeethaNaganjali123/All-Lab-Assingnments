package lab5;

import java.util.Scanner;

class EmployeeException extends RuntimeException
{
	EmployeeException()
	{
		System.out.println("salary should be above 3000");
	}
}
public class Exc6 {
	public static void main(String args[]) throws Exception
    {
   	 Scanner s=new Scanner(System.in);
   	 System.out.println("Enter salary: ");
   	 int sal=s.nextInt();
   	 s.close();
   	 try
   	 {
   		 if(sal<3000)
   		 throw new EmployeeException();
   		 else
   		  System.out.println("salary: "+sal);
         }
   	 catch(Exception e)
   	 {
   		 System.out.println(e);
   	 }
    }
}
