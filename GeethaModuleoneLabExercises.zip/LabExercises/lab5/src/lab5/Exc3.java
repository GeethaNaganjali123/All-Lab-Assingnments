package lab5;

import java.util.Scanner;

public class Exc3 {
	public static void main(String args[])
    {
  	  int i=0;
  	  int g;
  	  Scanner sc=new Scanner(System.in);
  	  int num=sc.nextInt();
  	  sc.close();
  	  for(i=2;i<num;i++)
  	  {
  		  g=0;
  		  for(int j=2;j<i;j++)
  		  {
  			  if(i%j==0)
  				  g=1;
  		  }
  		  if(g==0)
  		  {
  			  System.out.println(i);
  		  }
  	  }
    }
}
