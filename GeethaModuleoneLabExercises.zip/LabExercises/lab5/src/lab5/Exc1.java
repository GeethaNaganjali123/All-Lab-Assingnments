package lab5;
enum Traffic{
	RED,GREEN,YELLOW
}
public class Exc1 {
	Traffic color;
    public Exc1(Traffic color) {
  	  this.color=color;
    }
    public void selectColor() {
  	  switch(color)
  	  {
  	  case RED:
  		  System.out.println("Stop");
  		  break;
  	  case GREEN:
  		  System.out.println("go");
  		  break;
  	  case YELLOW:
  		  System.out.println("ready");
  		  break;
  		  default:
  			  System.out.println("Wrong selection");
      		  break;
  		  
  	  }
    }
    public static void main(String args[])
    {
  	  Exc1 g=new Exc1(Traffic.RED);
  	  g.selectColor();
    }
}
