package lab5;

import java.util.Scanner;

public class Exc2 {
	public static void main(String args[])
    {
   	 Scanner s=new Scanner(System.in);
   	 int n=s.nextShort();
   	 s.close();
   	 Fibnocci f=new Fibnocci();
   	 long res=f.input(n);
   	 System.out.println("non-recursive function:"+res);
   	 int res1=f.recursive(n);
   	 System.out.println("recursive function:"+res1);
    }
}
class Fibnocci
{
int n=1;
int b=1;
int c=0;
int count;
int input(int n)
{
	 count=n;
	 count=fabo(count);
	 return count;
}
int fabo(int count)
{
	 if(count!=2)
	 {
		 c=n+b;
		 n=b;
		 b=c;
		 fabo(--count);
	 }
	 return c;
}
int recursive(int n) 
{
	 int res=0;
	 if(n==1)
	 res=1;
	 else if(n==2)
		 res=1;
	 else
		 res=recursive(n-2)+recursive(n-1);
	     return res;
	 }
}
