package lab5;
import java.util.Scanner;
public class Ex5 {
        public static void main(String args[]) throws Exception
        {
        	Scanner s=new Scanner(System.in);
        	System.out.println("Enter age: ");
        	int age=s.nextInt();
        	s.close();
        	try
        	{
        		if(age<15)
        		
        			System.out.println("Age should be above 15");
        			else
        		System.out.println("Age: "+age);
        		
        	}
        	catch(Exception e)
        	{
        		System.out.println(e);
        	}
        }
}
