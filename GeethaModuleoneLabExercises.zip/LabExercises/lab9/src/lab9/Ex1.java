package lab9;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;
import java.util.Iterator;
import java.util.Scanner;
public class Ex1 {
     public static void main(String args[])
     {
    	 HashMap<Integer,String> hm=new HashMap<Integer,String>();
    	 System.out.println("Enter no of terms");
    	 Scanner sc=new Scanner(System.in);
    	 int n=sc.nextInt();
    	 System.out.println("Enter the elements");
    	 for(int i=0;i<n;i++) {
    		 hm.put(sc.nextInt(),sc.next());
    		 
    	 }
    	 Ex1 e=new Ex1();
    	 List<String> a= e.getValues(hm);
    	 System.out.println(a);
    	 sc.close();
    	 
     }
     List<String> getValues(HashMap<Integer,String> h){
    	 ArrayList<String> l=new ArrayList<String>();
    	 Set<Integer> keyset = h.keySet();
    	 Iterator<Integer> i= keyset.iterator();
    	 while(i.hasNext()) {
    		 Integer key=i.next();
    		 String b=(String)h.get(key);
    		 l.add(b);
    		 Collections.sort(l);
    	 }
    	 return l;
     }
}
